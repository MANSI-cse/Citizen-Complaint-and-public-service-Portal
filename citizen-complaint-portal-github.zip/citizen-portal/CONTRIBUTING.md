# Contributing to Citizen Complaint Portal

Thank you for your interest in improving this project! 🎉

## How to Contribute

1. **Fork** the repository
2. **Create a branch**: `git checkout -b feature/your-feature-name`
3. **Make your changes** and test them in the browser
4. **Commit**: `git commit -m "feat: describe your change"`
5. **Push**: `git push origin feature/your-feature-name`
6. **Open a Pull Request** with a clear description

## Ideas for Contribution

- Add multilingual support (Hindi, Punjabi, Tamil, etc.)
- Improve mobile responsiveness
- Add localStorage for persisting complaints
- Write unit tests for JS functions
- Improve accessibility (ARIA labels, keyboard nav)

## Code Style

- Use clear variable names
- Add comments for complex logic
- Keep functions small and focused
- Test in Chrome, Firefox, and Edge

## Reporting Bugs

Open an [Issue](../../issues) with:
- Steps to reproduce
- Expected vs actual behavior
- Browser and OS info
