# 🏛️ Citizen Complaint & Public Service Portal

<div align="center">

![Portal Banner](https://images.unsplash.com/photo-1597262975002-c5c3b14bbd62?w=900&h=300&fit=crop)

**Empowering Citizens. Bridging Governance. Driving Change.**

[![Live Demo](https://img.shields.io/badge/🚀_Live_Demo-Click_Here-blue?style=for-the-badge)](https://codepen.io/MANSI-cse/pen/ZYpOVMX)
[![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/HTML)
[![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)](https://developer.mozilla.org/en-US/docs/Web/CSS)
[![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg?style=for-the-badge)](LICENSE.txt)

</div>

---

## 📌 About The Project

The **Citizen Complaint & Public Service Portal** is a web-based grievance management system designed to bridge the communication gap between Indian citizens and government authorities — at every level from Gram Panchayat to Central Government.

> *"Your voice as a citizen helps build a stronger and better nation."*

This project was built with a focus on **accessibility, inclusivity, and real-world impact** — ensuring that both rural villagers and urban residents can raise their concerns and track resolution progress seamlessly.

---

## 🌟 Key Features

| Feature | Description |
|---|---|
| 🗂️ **Smart Complaint Registration** | Dynamic category system for Rural & Urban areas |
| 🎤 **Voice Assistant** | Speech-to-text input (Web Speech API, tuned for `en-IN`) |
| 🤖 **AI Complaint Generator** | Auto-generates formal complaint text from selections |
| 📍 **Live Location Detection** | Browser Geolocation API integration |
| 📊 **Analytics Dashboard** | Visual stats — Total, Resolved, Pending complaints |
| 🔄 **Status Tracker** | Step-by-step complaint progress tracker |
| 🗳️ **Community Voting** | Citizens upvote high-priority shared issues |
| 👤 **Anonymous Complaints** | Option to file complaints without identity |
| 📎 **Evidence Upload** | Photo/video attachment support |

---

## 🔄 System Workflow

```
┌────────────────────────────────────────────────────────────┐
│                    CITIZEN PORTAL FLOW                      │
└────────────────────────────────────────────────────────────┘

  [Citizen Visits Portal]
          │
          ▼
  ┌───────────────┐
  │  Select Area  │──── Rural ────┐
  │  Type         │               ├──► Dynamic Categories Load
  └───────────────┘──── Urban ───┘
          │
          ▼
  ┌───────────────────────────────────────────┐
  │            COMPLAINT INPUT                 │
  │  ┌──────────┐  ┌──────────┐  ┌─────────┐ │
  │  │ Manual   │  │ Voice 🎤 │  │ AI Bot  │ │
  │  │  Type    │  │ Input    │  │  🤖     │ │
  │  └──────────┘  └──────────┘  └─────────┘ │
  └───────────────────────────────────────────┘
          │
          ▼
  ┌───────────────┐
  │  Select Level │──► Gram Panchayat / District / State / Central
  └───────────────┘
          │
          ▼
  ┌───────────────────────┐
  │  Add Details          │
  │  • Location (GPS) 📍  │
  │  • Evidence Upload 📎  │
  │  • Anonymous Option 👤 │
  └───────────────────────┘
          │
          ▼
  ┌───────────────┐
  │    Submit     │
  └───────────────┘
          │
          ▼
  ┌──────────────────────────────────────────────┐
  │              STATUS TRACKER                   │
  │  [Submitted] → [Under Review] → [In Process] → [Resolved] │
  └──────────────────────────────────────────────┘
          │
          ▼
  ┌───────────────────────┐
  │  ANALYTICS DASHBOARD  │
  │  • Total Complaints   │
  │  • Resolved Count     │
  │  • Pending Count      │
  │  • Top Issues         │
  └───────────────────────┘
```

---

## 🗂️ Project Structure

```
citizen-portal/
│
├── 📁 src/                    # Source files (development)
│   ├── index.html             # Main HTML structure
│   ├── style.css              # Styling & responsive design
│   └── script.js              # Core JavaScript logic
│
├── 📁 dist/                   # Distribution files (production-ready)
│   ├── index.html
│   ├── style.css
│   └── script.js
│
├── 📁 docs/                   # Documentation & screenshots
│   └── screenshots/
│
├── README.md                  # This file
└── LICENSE.txt                # MIT License
```

---

## 🖥️ Screenshots

### 🏠 Home Page
> Landing page with civic message and hero imagery

![Home](https://images.unsplash.com/photo-1597262975002-c5c3b14bbd62?w=700&h=350&fit=crop)

---

### 📝 Complaint Registration
> Smart form with Rural/Urban category switcher, voice input, and AI generator

![Complaint Form](https://images.unsplash.com/photo-1450101499163-c8848c66ca85?w=700&h=350&fit=crop)

---

### 📊 Analytics Dashboard
> At-a-glance view of complaint statistics

| Metric | Count |
|--------|-------|
| Total Complaints | 120 |
| ✅ Resolved | 85 |
| ⏳ Pending | 35 |
| 🔝 Top Issue | Road Damage |

---

## ⚙️ Tech Stack

```
Frontend
├── HTML5          → Semantic structure, form elements
├── CSS3           → Custom layout, responsive design, animations
└── JavaScript     → DOM manipulation, API integrations
    ├── Web Speech API    → Voice input (en-IN locale)
    ├── Geolocation API   → GPS-based location detection
    └── File API          → Evidence upload handling
```

**No frameworks. No dependencies. Pure Web APIs.** ✅

---

## 🚀 Getting Started

### Prerequisites
- Any modern web browser (Chrome, Firefox, Edge)
- No installation required

### Run Locally

```bash
# Clone the repository
git clone https://github.com/YOUR_USERNAME/citizen-complaint-portal.git

# Navigate to project
cd citizen-complaint-portal

# Open in browser
open src/index.html
# OR just double-click index.html in your file explorer
```

### Live Demo
👉 [Open on CodePen](https://codepen.io/MANSI-cse/pen/ZYpOVMX)

---

## 🧠 JavaScript Functions Reference

| Function | Purpose |
|----------|---------|
| `showPage(page)` | SPA-style navigation between sections |
| `loadAreaCategories()` | Dynamically populates categories based on Rural/Urban |
| `startVoice()` | Initiates Web Speech API voice recognition |
| `generateAIComplaint()` | Auto-generates complaint text from user selections |
| `getLocation()` | Fetches GPS coordinates via Geolocation API |
| `vote()` | Increments community vote counter |

---

## 🌍 Real-World Impact

This project addresses a critical gap in Indian civic infrastructure:

- 🏘️ **Rural inclusion** — categories like Water Supply, Agriculture, Health Center for village-level issues
- 🏙️ **Urban coverage** — Traffic, Garbage, Public Transport for city dwellers
- 🗣️ **Language accessibility** — Voice input in `en-IN` for low-literacy users
- 🔒 **Privacy-first** — Anonymous complaint filing option
- 📡 **Multi-level escalation** — From Gram Panchayat → District → State → Central

---

## 🔮 Future Enhancements

- [ ] Backend integration (Node.js / Firebase)
- [ ] Real database for complaint storage (MongoDB)
- [ ] SMS/Email notifications on status update
- [ ] Multilingual support (Hindi, Punjabi, Tamil...)
- [ ] Admin dashboard for government officials
- [ ] Real-time chart using Chart.js / D3.js
- [ ] PWA support for offline access
- [ ] OTP-based citizen authentication

---

## 👩‍💻 Author

**Mansi** — Computer Science & Engineering Student

[![GitHub](https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white)](https://github.com/YOUR_USERNAME)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://linkedin.com/in/YOUR_PROFILE)
[![CodePen](https://img.shields.io/badge/CodePen-000000?style=for-the-badge&logo=codepen&logoColor=white)](https://codepen.io/MANSI-cse)

---

## 📄 License

This project is licensed under the **MIT License** — see [LICENSE.txt](LICENSE.txt) for details.

---

<div align="center">

⭐ **If this project inspired you, give it a star!** ⭐

*Built with ❤️ for Indian citizens*

</div>
