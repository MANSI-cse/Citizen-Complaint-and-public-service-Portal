# 📤 How to Upload This Project to GitHub

Follow these steps to publish your Citizen Complaint Portal so recruiters can find it.

---

## Step 1 — Create a New GitHub Repository

1. Go to [github.com](https://github.com) and sign in
2. Click the **+** (top right) → **New repository**
3. Settings:
   - **Name**: `citizen-complaint-portal`
   - **Description**: `🏛️ A web-based civic grievance system for Indian citizens — with voice input, AI complaint generator, GPS location, and multi-level escalation`
   - **Visibility**: Public ✅
   - **Initialize**: ✅ Add a README (we'll replace it)
4. Click **Create repository**

---

## Step 2 — Upload Your Files

### Option A — GitHub Web (Easiest)
1. In your repo, click **Add file → Upload files**
2. Drag & drop all files from this ZIP:
   - `README.md`
   - `LICENSE.txt`
   - `CONTRIBUTING.md`
   - `.gitignore`
   - `src/` folder (index.html, style.css, script.js)
   - `dist/` folder
3. Write commit message: `feat: initial project upload`
4. Click **Commit changes**

### Option B — Git CLI
```bash
git clone https://github.com/YOUR_USERNAME/citizen-complaint-portal.git
cd citizen-complaint-portal
# Copy all files here
git add .
git commit -m "feat: initial project upload — Citizen Complaint Portal"
git push origin main
```

---

## Step 3 — Enable GitHub Pages (Live Demo!)

1. Go to **Settings → Pages**
2. Source: **Deploy from a branch**
3. Branch: `main` / folder: `/dist`
4. Click **Save**
5. Your live link appears in ~1 min: `https://YOUR_USERNAME.github.io/citizen-complaint-portal`
6. **Update README.md** — replace the demo badge URL with this live link!

---

## Step 4 — Polish Your Profile

- Add **topics** (right side of repo homepage): `html`, `css`, `javascript`, `civic-tech`, `government`, `india`, `web-speech-api`, `geolocation`
- Pin this repo on your GitHub profile
- Update your LinkedIn with the live link

---

## Step 5 — Share With Recruiters

Your repo link: `https://github.com/YOUR_USERNAME/citizen-complaint-portal`

Include in your resume/portfolio:
> **Citizen Complaint & Public Service Portal** | HTML · CSS · JavaScript · Web APIs  
> Civic grievance system with voice input, AI text generation, GPS detection, and multi-level government escalation. Live demo ↗

---

*Good luck! 🚀*
