/* PAGE NAVIGATION */

function showPage(page){

let sections = document.querySelectorAll("section");

sections.forEach(function(sec){
sec.classList.remove("active");
});

document.getElementById(page).classList.add("active");

}


/* RURAL / URBAN CATEGORY SYSTEM */

function loadAreaCategories(){

let area = document.getElementById("areaType").value;

let category = document.getElementById("category");

category.innerHTML="";

let options=[];

if(area==="Rural"){

options=[
"Water Supply",
"Village Road",
"Agriculture",
"Health Center",
"Food Distribution",
"Electricity",
"Sanitation"
];

}

else if(area==="Urban"){

options=[
"Traffic",
"Garbage Management",
"Public Transport",
"Hospital",
"Food Safety",
"Electricity",
"Building Infrastructure"
];

}

options.forEach(function(opt){

let option=document.createElement("option");

option.text=opt;

category.add(option);

});

}


/* VOICE ASSISTANT */

function startVoice(){

const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();

recognition.lang="en-IN";

recognition.onresult=function(event){

document.getElementById("complaintText").value =
event.results[0][0].transcript;

};

recognition.start();

}


/* AI COMPLAINT GENERATOR */

function generateAIComplaint(){

let category=document.getElementById("category").value;

let area=document.getElementById("areaType").value;

let text="I would like to report an issue regarding "+category+
" in my "+area+
" area. This problem is affecting residents and needs urgent attention from the concerned authorities. Kindly take necessary action to resolve this issue.";

document.getElementById("complaintText").value=text;

}


/* LOCATION DETECTION */

function getLocation(){

navigator.geolocation.getCurrentPosition(function(position){

document.getElementById("location").value =
position.coords.latitude + "," + position.coords.longitude;

});

}


/* COMMUNITY VOTING */

let votes = 0;

function vote(){

votes++;

document.getElementById("voteCount").innerText =
"Votes: " + votes;

}
